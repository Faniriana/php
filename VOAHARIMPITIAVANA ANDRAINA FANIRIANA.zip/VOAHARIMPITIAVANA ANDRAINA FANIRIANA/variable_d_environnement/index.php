<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h2>Variables d'environnement</h2>
    <table>
        <tr>
            <th>Variable</th>
            <th>Valeur</th>
            <th>Signification</th>
        </tr>
        <style>
            th, td {
            border: 1px solid;
        }

        th {
            background-color: lightgrey;
        }
        </style>
        <?php
        // Liste des variables d'environnement
        $variables = array(
            'SERVER_ADDR' => 'Adresse IP du serveur',
            'HTTP_HOST' => 'Hôte HTTP',
            'REMOTE_ADDR' => 'Adresse IP du client',
            'HTTP_USER_AGENT' => 'Agent utilisateur HTTP'
        );

        // Affichage des variables d'environnement
        foreach ($variables as $variable => $signification) {
            echo "<tr><td>\$$variable</td><td>{$_SERVER[$variable]}</td><td>$signification</td></tr>";
        }

        // Ajout de la variable et de sa valeur pour gethostbyAddr($REMOTE_ADDR)
        $hostname = 'localhost';
        echo "<tr><td>gethostbyAddr(\$REMOTE_ADDR)</td><td>$hostname</td><td>Nom d'hôte associé à l'adresse IP du client</td></tr>";
        ?>
    </table>
</body>
</html>