<?php
// Définition de la classe Personne
class Personne {
    // Propriétés
    public $nom;
    public $prenom;

    // Constructeur
    public function __construct($nom, $prenom) {
        $this->nom = $nom;
        $this->prenom = $prenom;
    }

    // Méthode pour présenter la personne
    public function presenter() {
        return "Je m'appelle " . $this->nom . " " . $this->prenom;
    }
}

// Création d'une instance de Personne
$personne = new Personne("andraina", "faniriana");

// Appel de la méthode presenter()
echo $personne->presenter();
?>
