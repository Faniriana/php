<?php
// Définition de la classe Personne
class Personne {
    // Propriétés
    public $nom;
    public $prenom;

    // Constructeur
    public function __construct($nom, $prenom) {
        $this->nom = $nom;
        $this->prenom = $prenom;
    }

    // Méthode pour présenter la personne
    public function presenter() {
        return "Je m'appelle " . $this->nom . " " . $this->prenom;
    }
}

// Programme de test
// Création de deux instances de Personne
$personne1 = new Personne("RAZAKAMIADANA", "Kely");
$personne2 = new Personne("MIZA", "be");

// Affichage des descriptions des personnes
echo $personne1->presenter() . "<br>";

echo $personne2->presenter();
?>
