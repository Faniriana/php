<?php
// Définition de la classe Personne
class Personne {
    // Propriétés
    public $nom;
    public $prenom;
    public $date_naissance;

    // Constructeur
    public function __construct($nom, $prenom, $date_naissance) {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->date_naissance = $date_naissance;
    }

    // Méthode pour présenter la personne
    public function presenter() {
        return "Je m'appelle " . $this->prenom . " " . $this->nom;
    }

    // Méthode pour calculer l'âge
    public function age() {
        $date_actuelle = new DateTime('now');
        $date_naissance = new DateTime($this->date_naissance);
        $difference = $date_naissance->diff($date_actuelle);
        return $difference->y; // Renvoie l'âge en années
    }
}

// Programme de test
// Création d'une instance de Personne avec date de naissance
$personne = new Personne("Doe", "John", "1990-05-15");

// Affichage de la description et de l'âge de la personne
echo $personne->presenter() . "<br>";
echo "J'ai " . $personne->age() . " ans.";
?>
