<!DOCTYPE html>
<html>
<head>
    <title>Hello PHP</title>
    <style>
        th, td {
            border: 1px solid;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1> 
    <?php
    //1.1
    $heure = date("H");
    echo "Hello PHP, nous sommes le " . date("d/m/Y") . "</br>";
    //1.2
    if ($heure < 12) {
        echo "Bon matin!";
    } else {
        echo "Bonne après-midi!";
    }
    ?>
    </h1>

</body>
</html>
