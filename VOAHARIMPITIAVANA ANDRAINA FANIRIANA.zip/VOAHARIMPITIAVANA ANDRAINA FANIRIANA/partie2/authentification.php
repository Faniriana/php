<?php
require_once "verif.php";

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pseudo = $_POST['pseudo'];
    $motpasse = $_POST['motpasse'];
    $resultat = verif($pseudo, $motpasse);
    if ($resultat) {
        $_SESSION['pseudo'] = $pseudo;
        header("Location: page_privee.php");
        exit();
    } else {
        echo "<!DOCTYPE html>
        <html>
        <head>
            <title>Authentification</title>
        </head>
        <body>
            <h1>Authentification</h1>
            <p>Pseudo ou mot de passe incorrect.</p>
            <p><a href='authentification.html'>Retourner au formulaire</a></p>
        </body>
        </html>";
    }
}
?>