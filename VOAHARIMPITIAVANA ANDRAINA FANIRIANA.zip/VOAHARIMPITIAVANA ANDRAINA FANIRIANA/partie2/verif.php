<?php
    // verif.php

// Définir les paramètres de connexion à la base de données
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'MySql');

// Se connecter à la base de données
$pdo = new PDO("mysql:host=".DB_SERVER.";dbname=".DB_NAME, DB_USERNAME, DB_PASSWORD);

// Définir la fonction verif()
function verif($pseudo, $motpasse) {
    global $pdo; // Rendre la variable $pdo globale
    // Construire la requête SQL avec des paramètres nommés
    $sql = "SELECT * FROM Membres WHERE pseudo = :pseudo AND motpasse = :motpasse";
    // Préparer la requête
    $stmt = $pdo->prepare($sql);
    // Exécuter la requête avec les valeurs des paramètres
    $stmt->execute(['pseudo' => $pseudo, 'motpasse' => $motpasse]);
    // Récupérer le résultat sous forme de tableau associatif
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // Vérifier si le résultat est vide ou non
    if ($row) {
        // L'utilisateur est trouvé, renvoyer true
        return true;
    } else {
        // L'utilisateur n'est pas trouvé, renvoyer false
        return false;
    }
}
?>