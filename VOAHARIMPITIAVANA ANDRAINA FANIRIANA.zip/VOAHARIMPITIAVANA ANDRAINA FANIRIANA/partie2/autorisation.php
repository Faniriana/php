<?php
session_start();

if (isset($_SESSION['pseudo'])) {
} else {
    header("Location: authentification.html");
    exit();
}
?>